import { Component, OnInit } from '@angular/core';
declare var $:any;
declare const M;
declare var options;
declare var fullWidth;

@Component({
  selector: 'app-android',
  templateUrl: './android.component.html',
  styleUrls: ['./android.component.css']
})
export class AndroidComponent implements OnInit {

  constructor() { }

  ngOnInit() {

    this.jquery_code();
  }

  jquery_code(){

    document.addEventListener('DOMContentLoaded', function() {
      var elems = document.querySelectorAll('.sidenav');
      var instances = M.Sidenav.init(elems, options);
    });

    $(document).ready(function(){
      $('.sidenav').sidenav();
    });

    document.addEventListener('DOMContentLoaded', function() {
      var elems = document.querySelectorAll('.carousel');
      var instances = M.Carousel.init(elems, options);
      
    });
  
    // Or with jQuery
  
    $(document).ready(function(){
      $('.carousel').carousel();

    });

        
  }

}

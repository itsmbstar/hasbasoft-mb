import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
declare var $:any;
declare const M;
declare var options;
@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {

  constructor() { }

  ngOnInit() {

    this.jquery_code();
    
  }
  jquery_code(){

   
    document.addEventListener('DOMContentLoaded', function() {
      var elems = document.querySelectorAll('.sidenav');
      var instances = M.Sidenav.init(elems, options);
    });
  
    // Or with jQuery
  
    $(document).ready(function(){
      $('.sidenav').sidenav();
    });

  }
}
